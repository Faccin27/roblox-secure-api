import { Injectable, NestMiddleware } from "@nestjs/common";

const requests = new Map<string, { count: number; reset: number }>();

@Injectable()

export class RateLimitMiddleware implements NestMiddleware {
    limit = 30; // per minute
    windowMs = 60 * 1000;

    use(req: any, res: any, next: () => void) {
        const ip = req.ip || req.connection.remoteAddress;
        const now = Date.now();
        const entry = requests.get(ip)

        if (!entry || now > entry.reset) {
            requests.set(ip, { count: 1, reset: now + this.windowMs });
            return next();
        }

        if (entry.count >= this.limit) {
            return res.status(429).json({
                ok: false,
                message: 'rate limit exceeded'
            });
        }
        entry.count++
        next();
    }
}