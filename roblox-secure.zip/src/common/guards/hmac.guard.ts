import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';

import { validateSignature } from '../utils/hmac';

@Injectable()
export class HmacGuard implements CanActivate {
    canActivate(context: ExecutionContext): boolean {

        const req = context.switchToHttp().getRequest();

        const signature = req.headers['x-signature'];
        const timestamp = req.headers['x-timestamp'];

        if (!signature || !timestamp) {
            throw new UnauthorizedException('Missing signature headers');
        }

        const isValid = validateSignature(req.body, process.env.ROBLOX_SECRET!, signature, timestamp);

        if (!isValid) {
            throw new UnauthorizedException('Invalid signature');
        }

        return true;

    }
}