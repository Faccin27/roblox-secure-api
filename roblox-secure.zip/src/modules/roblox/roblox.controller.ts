import { Controller, Post, Body, Ip, UseGuards } from '@nestjs/common';

import { HmacGuard } from '../../common/guards/hmac.guard';

import { WebhookService } from '../webhook/webhook.service';

@Controller('roblox')
export class RobloxController {
  constructor(private readonly webhook: WebhookService) { }

  @UseGuards(HmacGuard)
  @Post('validate-player')
  async validatePlayer(@Body() body: any, @Ip() ip: string) {
    await this.webhook.sendAction({
      keyName: body.keyName,
      ip,
      timestamp: Date.now(),
      username: body.username
    })

    return {
      ok: true,
    }
  }

}